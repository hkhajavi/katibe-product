<div dir="rtl">

### مراحل استفرار پروژه پلزمیک

1. از این ریپو یک فورک با نام پروژه خود گرفته.
2. از طریق همروش یک اپ از نوع منبع گیت بسازید. ![image](https://github.com/makefragment/template/assets/46134157/91a5ccc9-11ea-4aca-940b-4be9d47f0ea7)
3.  آدرس ریپو را همان ریپویی انتخاب کنید که در مرحله 1 ساختید.
4.  روی دکمه تنظیمات اپ کلیک کنید و به مرحله بعد بروید.
5.  نام دلخواه برای اپ بگذارید.
6.  در فیلد پورت سرویس مقدار 3000 را بنویسید. ![image](https://github.com/makefragment/template/assets/46134157/b48d8f3e-f2ac-4b7d-8c87-ca4206d85c73)
7.  از بخش آدرس دامنه یک آدرس دامنه وارد کنید. ![image](https://github.com/makefragment/template/assets/46134157/c85eb924-4bd8-4ad1-bfe1-974cbcdd91c1)
8.  سپس روی دکمه انتخاب پلن کلیک کنید و کلاستر و name space را انتخاب کنید و در نهایت روی دکمه ساخت اپ کلیک کنید.
9.  پس از ساخت اپ منتظر بمانید تا وضعیت پادها به رنگ سبز و متن running تغییر کند (این بخش ممکنه تا ۵ دقیقه طول بکشد.) ![image](https://github.com/makefragment/template/assets/46134157/0b703e75-9cf0-44e2-8a4a-a79ceef8e304)
10.  حالا در پلزمیک یک پروژه جدید ساخته
11.  در کنار نام پروژه روی سه نقطه کلیک کرده و گزینه Configure custom app host کلیک کنید. ![image](https://github.com/makefragment/template/assets/46134157/68226350-04b0-4267-94dc-bb644f42ec58)
12.  در پنجره باز شده، مقداری با همین فرمت وارد کنید. custom-doamin]/plasmic-host] به جای [custom-domain] همان دامنه ای در مرحله 7 وارد کرده اید بنویسید. مثلا www.paziresh24.com/plasmic-host


</div>

